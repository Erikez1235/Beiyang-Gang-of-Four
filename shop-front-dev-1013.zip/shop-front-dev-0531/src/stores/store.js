import { reactive } from 'vue'

export const store = reactive({
  count: 1,
  userInfi: {
    usernname: '',
    realName: '',
    mobile: ''
  },
  productList: []
})
