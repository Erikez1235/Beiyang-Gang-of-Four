<template>
  <div>
    <ShopHeader></ShopHeader>
    <div class="shopcontact">Contact</div>
    <ShopFooter></ShopFooter>
  </div>
</template>

<script setup lang="ts">
    import ShopHeader from "../components/shop/ShopHeader.vue"
    import ShopFooter from "../components/shop/ShopFooter.vue"
</script>

<style scoped>
  .shopcontact {
    width: 1280px;
    height: 100px;
  }
</style>
