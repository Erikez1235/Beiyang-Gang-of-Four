<template>
  <div>
    <ShopHeader></ShopHeader>
    <div class="shopabout">
      About
      <button @click="store.count++">
        Counter++: {{ store.count }}
      </button>
    </div>
    <!--
    <el-row>
      <el-col :span="4" v-for="item in store.productList" :key="item.id">
        <el-card :body-style="{ padding: '0px' }">
          <img src="@/assets/book.png" class="image"/>
          <div style="padding: 14px">
            <span>{{ item.id + "-" + item.productName }}</span>
            <div class="bottom">
              <el-button class="button">商品详情</el-button>
              <el-button type="primary" class="button">立即下单！</el-button>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>-->
    <ShopFooter></ShopFooter>
  </div>
</template>

<script setup lang="ts">
  import ShopHeader from "../components/shop/ShopHeader.vue"
  import ShopFooter from "../components/shop/ShopFooter.vue"

  import { store } from '@/stores/store.js'
</script>

<style scoped>
  .shopabout {
    display: inline-block;
    width: 1280px;
    height: 100px;
  }
</style>
