<template>
  <div>
    <ShopHeader></ShopHeader>
    <div class="shopproduct">All Products</div>
    <ShopFooter></ShopFooter>
  </div>
</template>

<script setup lang="ts">
    import ShopHeader from "../components/shop/ShopHeader.vue"
    import ShopFooter from "../components/shop/ShopFooter.vue"
</script>

<style scoped>
  .shopproduct {
    width: 1280px;
    height: 100px;
  }
</style>
