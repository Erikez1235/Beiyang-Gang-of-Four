<template>
  <div>用户个人中心</div>
</template>

<script>
  export default {
    name: "UCenterPage"
  }
</script>

<style scoped>

</style>
