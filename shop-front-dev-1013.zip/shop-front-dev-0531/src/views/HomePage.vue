<template>
  <div>
    <div>
      <ShopHeader></ShopHeader>
      <ShopBanner></ShopBanner>
      <ShopMain></ShopMain>
      <ShopFooter></ShopFooter>
    </div>
  </div>

</template>

<script setup lang="ts">
import ShopHeader from "../components/shop/ShopHeader.vue"
import ShopBanner from "../components/shop/ShopBanner.vue"
import ShopMain from "../components/shop/ShopMain.vue"
import ShopFooter from "../components/shop/ShopFooter.vue"
</script>

<style scoped>

</style>
