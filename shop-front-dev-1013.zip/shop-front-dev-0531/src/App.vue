<script setup lang="ts">
import { RouterLink, RouterView } from 'vue-router'
import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <RouterView class="app-view" />
</template>

<style scoped>
  .app-view {
    margin: 0 auto;
  }
</style>
