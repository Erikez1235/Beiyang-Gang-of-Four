<template>
  <div class="shop-header">
    <header>
      <img alt="Vue logo" class="logo" src="@/assets/logo.svg" width="125" height="125" />
      <div class="search-wrapper">
        <el-select v-model="categorySelectedVal" class="cate-selector" placeholder="Select">
          <el-option
              v-for="item in categoryOptions"
              :key="item.value"
              :label="item.label"
              :value="item.value"
          />
        </el-select>
        <el-input v-model="searchKeyword" class="search-input" placeholder="请输入商品名称" />
        <el-button type="primary" plain>搜索
          <el-icon class="el-icon--right"><Search /></el-icon>
        </el-button>
        <div class="btn-group">
          <el-button link type="primary">注册</el-button>
          <span>/</span>
          <el-button link type="primary">登录</el-button>
        </div>
        <div class="btn-group">
          <el-button :icon="Message" circle /><span>&nbsp;</span>
          <el-button :icon="Iphone" circle /><span>&nbsp;</span>
          <el-button :icon="Location" circle />
        </div>
        <div class="btn-group">
          <el-select v-model="langSelectedVal" class="lang-selector" size="small" placeholder="Select">
            <el-option
                v-for="item in langOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </div>
      </div>
    </header>
    <div style="border-bottom: 1px solid gray">
      <div style="display: inline-block; width: 248px; height: 60px">
        <el-menu
            :default-active="activeIndex"
            class="el-menu-demo"
            mode="horizontal"
            @select="handleSelect">
          <el-sub-menu index="1">
            <template #title>商品分类</template>
            <el-menu-item index="2-1">item one</el-menu-item>
            <el-menu-item index="2-2">item two</el-menu-item>
            <el-menu-item index="2-3">item three</el-menu-item>
            <el-sub-menu index="2-4">
              <template #title>item four</template>
              <el-menu-item index="2-4-1">item one</el-menu-item>
              <el-menu-item index="2-4-2">item two</el-menu-item>
              <el-menu-item index="2-4-3">item three</el-menu-item>
            </el-sub-menu>
          </el-sub-menu>
        </el-menu>
      </div>
      <nav style="display: inline-block; width: 1000px; height: 60px">
        <RouterLink class="nav-item" to="/">首页</RouterLink>
        <RouterLink class="nav-item" to="/products">所有商品</RouterLink>
        <RouterLink class="nav-item" to="/about">关于平台</RouterLink>
        <RouterLink class="nav-item" to="/contact">联系我们</RouterLink>
      </nav>
    </div>
  </div>
</template>

<script setup lang="ts">
    import { Search, Message, Iphone, Location } from '@element-plus/icons-vue'
    import { ref } from 'vue'

    const searchKeyword = ref('')
    const categorySelectedVal = ref(0)
    const categoryOptions = [
        {
            value: 0,
            label: '所示商品',
        },
        {
            value: 1,
            label: '最新上架',
        },
        {
            value: 2,
            label: '户外用品',
        },
        {
            value: 3,
            label: '宿舍神器',
        },
        {
            value: 4,
            label: '课本/教材',
        },
    ]
    const langSelectedVal = ref('cn')
    const langOptions = [
        {
            value: 'cn',
            label: '中文',
        },
        {
            value: 'en',
            label: 'English',
        }
    ]
</script>

<style scoped>
  .shop-header {
    display: inline-block;
    width: 1280px;
  }
  .search-wrapper {

  }
  .cate-selector {
    width: 145px;
  }
  .search-input {
    width: 450px;
  }
  .el-input__wrapper {
    width: 450px;
  }
  .btn-group {
    display: inline-block;
    margin-left: 30px;
  }
  .el-button+.el-button {
    margin-left: 0px;
  }
  .lang-selector {
    width: 80px;
  }
  .nav-item {
    width: 160px;
    text-align: center;
  }
  header {
    line-height: 1.5;
    max-height: 100vh;

  }

  .logo {
    display: block;
    margin: 0 auto 2rem;
  }

  nav {
    width: 100%;
    font-size: 12px;
    text-align: center;
    margin-top: 2rem;
    display: inline-flex;
  }

  nav a.router-link-exact-active {
    color: var(--color-text);
  }

  nav a.router-link-exact-active:hover {
    background-color: transparent;
  }

  nav a {
    display: inline-block;
    padding: 0 1rem;
    border-left: 1px solid var(--color-border);
  }

  nav a:first-of-type {
    border: 0;
  }

  @media (min-width: 800px) {
    header {
      display: flex;
      place-items: center;
      padding-right: calc(var(--section-gap) / 2);
    }

    .logo {
      margin: 0 2rem 0 0;
    }

    header .wrapper {
      display: flex;
      place-items: flex-start;
      flex-wrap: wrap;
    }

    nav {
      text-align: left;
      margin-left: -1rem;
      font-size: 1rem;

      padding: 1rem 0;
      margin-top: 1rem;
    }
  }
</style>
