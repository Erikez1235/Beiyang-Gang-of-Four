<template>
  <div class="shop-footer">
    <el-row class="footer-nav" :gutter="20">
      <el-col :span="6"><div class="grid-content ep-bg-purple" />
        联系方式
      </el-col>
      <el-col :span="6"><div class="grid-content ep-bg-purple" />
        网站导航
      </el-col>
      <el-col :span="6"><div class="grid-content ep-bg-purple" />
        站内搜索
      </el-col>
      <el-col :span="6"><div class="grid-content ep-bg-purple" />
        显示语言
      </el-col>
    </el-row>
    <el-row class="copyright" :gutter="20">
      <span style="margin: 0 auto; text-align: center;">Copyright ® sdev.edu.cn All Right Reserved.</span>
    </el-row>
  </div>
</template>

<script setup lang="ts">

</script>

<style scoped>
  .shop-footer {
    height: 100%;
    width: 1280px;
  }
  .footer-nav {
    height: 300px;
    background: cornflowerblue;
    text-align: center;
  }
  .el-row {
    /*margin-bottom: 20px;*/
  }
  .el-row:last-child {
    margin-bottom: 0;
  }
  .el-col {
    border-radius: 4px;
  }

  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .copyright {
    background: cadetblue;
    text-align: center;
  }
</style>
