<template>
  <div class="shop-main">
    <el-row>
      <el-col :span="8"><div class="grid-content">
        最新上架
      </div>
      </el-col>
      <el-col :span="16">
        <div class="grid-content">
          热门品类
          <button @click="store.count++">
            Counter++: {{ store.count }}
          </button>
        </div>
      </el-col>
    </el-row>
    <el-row>
      <el-row><h3>推荐商品</h3></el-row>
      <el-row>
        <el-col :span="4" v-for="item in productList" :key="item.id">
          <el-card :body-style="{ padding: '0px' }">
            <img src="@/assets/book.png" class="image"/>
            <div style="padding: 14px">
              <span>{{ item.id + "-" + item.productName }}</span>
              <div class="bottom">
<!--                <time class="time">{{ currentDate }}</time>-->
                <el-button class="button">商品详情</el-button>
                <el-button type="primary" class="button">立即下单！</el-button>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </el-row>
  </div>
</template>

<script setup lang="ts">
  import axios from 'axios'
  import { ref } from 'vue'
  import { onMounted } from 'vue'
  import { store } from '@/stores/store.js'

  let productList = ref([1,2,3,4,5,6]);
  let produclTotal = ref(0);

  onMounted(() => {
    console.log(`the component is now mounted.`)
    loadSaleRankList()
    console.log(productList);
    console.log(produclTotal);
  })

  function loadSaleRankList() {
    const res = axios.get('http://localhost:8088/timbercld/service/front/products/ranklist?order=&orderField=&page=1&limit=6')
      .then(function (response) {
        // handle success
        console.log(response);
        if (0 == response.data.code) {
          productList = response.data.data.list;
          produclTotal = response.data.data.total;
          store.productList = response.data.data.list;
        }
      })
      .catch(function (error) {
        // handle error
        // console.log(error);
      })
      .finally(function () {
        // always executed
      });
  }



</script>

<style scoped>
  .shop-main {
    margin-bottom: 40px;
  }
  .el-row {
    margin-bottom: 20px;
  }
  .el-row:last-child {
    margin-bottom: 0;
    text-align: center;
  }
  .el-col {
    border-radius: 4px;
    background: lightgrey;
    height: 100%;
    text-align: center;
  }

  .grid-content {
    border-radius: 4px;
    min-height: 80px;
  }

  .time {
    font-size: 12px;
    color: #999;
  }

  .bottom {
    margin-top: 13px;
    line-height: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  .button {
    /*padding: 0;*/
    width: 90px;
    min-height: auto;
  }

  .image {
    width: 100%;
    display: block;
    padding: 12px;
  }
</style>
