<template>
  <el-card shadow="never" class="aui-card--fill">
    <el-form :inline="true" :model="hooksData.dataForm" @keyup.enter="getDataList()">
      <el-form-item>
        <el-button type="primary" @click="showEditDialogHandle()">{{ t('add') }}</el-button>
      </el-form-item>
    </el-form>
    <el-table v-loading="hooksData.dataListLoading" :data="hooksData.dataList" border style="width: 100%">
      <el-table-column type="index" :label="t('index')" header-align="center" align="center" width="60"></el-table-column>
      <el-table-column :label="t('handle')" header-align="center" align="center" width="150">
        <template #default="scope">
          <el-button link size="small" @click="showEditDialogHandle(scope.row.id)">{{ t('update') }}</el-button>
          <el-button link size="small" @click="deleteHandle(scope.row.id)">{{ t('delete') }}</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="productName" :label="t('products.productName')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="shopName" :label="t('products.shopName')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="productPrice" :label="t('products.productPrice')" header-align="center" width="120" align="center"></el-table-column>
      <el-table-column prop="productIntro" :label="t('products.productIntro')" header-align="center" width="240" align="center"></el-table-column>
      <el-table-column prop="productImg" :label="t('products.productImg')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="updateDate" :label="t('products.updateDate')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="createDate" :label="t('products.createDate')" header-align="center" width="180" align="center"></el-table-column>
    </el-table>
    <el-pagination :current-page="hooksData.page"
                   :page-sizes="[10, 20, 50, 100]"
                   :page-size="hooksData.limit"
                   :total="hooksData.total"
                   layout="total, sizes, prev, pager, next, jumper"
                   :small="true"
                   @size-change="onPageSizeChange"
                   @current-change="onPageCurrentChange">
    </el-pagination>
    <edit-dialog v-if="hooksData.editDialogVisible"
                 ref="editDialogRef"
                 @refreshPageHandle="getDataList">
    </edit-dialog>
  </el-card>
</template>
<script setup lang="ts">
  import { watch } from 'vue'
  import useHooks from '@/hooks'
  import { useI18n } from 'vue-i18n'
  import EditDialog from './products-edit-dialog.vue'

  const { t } = useI18n()

  const {
    hooksOptions,
    hooksData,
    getDataList,
    onPageSizeChange,
    onPageCurrentChange,
    deleteHandle,
    showEditDialogHandle
  } = useHooks()

  hooksOptions.getListURL = '/shop/products/page'
  hooksOptions.needPage = true
  hooksOptions.deleteURL = '/shop/products/delete'
  hooksOptions.multiDelete = false

  hooksData.dataForm = {
    productName: ''
  }

  watch([() => hooksData.daterange], (val1) => {
    hooksData.dataForm.startDate = val1[0][0]
    hooksData.dataForm.endDate = val1[0][1]
  })
</script>
