<template>
  <el-card shadow="never" class="aui-card--fill">
    <el-form :inline="true" :model="hooksData.dataForm" @keyup.enter="getDataList()">
      <el-form-item>
        <el-button type="primary" @click="showEditDialogHandle()">{{ t('add') }}</el-button>
      </el-form-item>
    </el-form>
    <el-table v-loading="hooksData.dataListLoading" :data="hooksData.dataList" border style="width: 100%">
      <el-table-column type="index" :label="t('index')" header-align="center" align="center" width="60"></el-table-column>
      <el-table-column :label="t('handle')" header-align="center" align="center" width="150">
        <template #default="scope">
          <el-button link size="small" @click="showEditDialogHandle(scope.row.id)">{{ t('update') }}</el-button>
          <el-button link size="small" @click="deleteHandle(scope.row.id)">{{ t('delete') }}</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="shopName" :label="t('order.shopName')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="shopId" :label="t('order.shopId')" header-align="center" width="120" align="center"></el-table-column>
      <el-table-column prop="customerName" :label="t('order.customerName')" header-align="center" width="120" align="center"></el-table-column>
      <el-table-column prop="customerId" :label="t('order.customerId')" header-align="center" width="120" align="center"></el-table-column>
      <el-table-column prop="productsName" :label="t('order.productsName')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="productsId" :label="t('order.productsId')" header-align="center" width="240" align="center"></el-table-column>
      <el-table-column prop="quantity" :label="t('order.quantity')" header-align="center" width="120" align="center"></el-table-column>
      <el-table-column prop="amount" :label="t('order.amount')" header-align="center" width="120" align="center"></el-table-column>
      <el-table-column prop="comment" :label="t('order.comment')" header-align="center" width="120" align="center"></el-table-column>
      <!--      <el-table-column prop="productImg" :label="t('order.productImg')" header-align="center" width="180" align="center"></el-table-column>-->
      <el-table-column prop="updateDate" :label="t('order.updateDate')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="createDate" :label="t('order.createDate')" header-align="center" width="180" align="center"></el-table-column>
    </el-table>
    <el-pagination :current-page="hooksData.page"
                   :page-sizes="[10, 20, 50, 100]"
                   :page-size="hooksData.limit"
                   :total="hooksData.total"
                   layout="total, sizes, prev, pager, next, jumper"
                   :small="true"
                   @size-change="onPageSizeChange"
                   @current-change="onPageCurrentChange">
    </el-pagination>
    <edit-dialog v-if="hooksData.editDialogVisible"
                 ref="editDialogRef"
                 @refreshPageHandle="getDataList">
    </edit-dialog>
  </el-card>
</template>
<script setup lang="ts">
  import { watch } from 'vue'
  import useHooks from '@/hooks'
  import { useI18n } from 'vue-i18n'
  import EditDialog from './order-edit-dialog.vue'

  const { t } = useI18n()

  const {
    hooksOptions,
    hooksData,
    getDataList,
    onPageSizeChange,
    onPageCurrentChange,
    deleteHandle,
    showEditDialogHandle
  } = useHooks()

  hooksOptions.getListURL = '/shop/order/page'
  hooksOptions.needPage = true
  hooksOptions.deleteURL = '/shop/order/delete'
  hooksOptions.multiDelete = false

  hooksData.dataForm = {
    productName: ''
  }

  watch([() => hooksData.daterange], (val1) => {
    hooksData.dataForm.startDate = val1[0][0]
    hooksData.dataForm.endDate = val1[0][1]
  })
</script>
