<template>
  <el-card shadow="never" class="aui-card--fill">
    <el-form :inline="true" :model="hooksData.dataForm" @keyup.enter="getDataList()">
      <el-form-item>
        <el-button type="primary" @click="showEditDialogHandle()">{{ t('add') }}</el-button>
      </el-form-item>
    </el-form>
    <el-table v-loading="hooksData.dataListLoading" :data="hooksData.dataList" bcustomer style="width: 100%">
      <el-table-column type="index" :label="t('index')" header-align="center" align="center" width="60"></el-table-column>
      <el-table-column :label="t('handle')" header-align="center" align="center" width="150">
        <template #default="scope">
          <el-button link size="small" @click="showEditDialogHandle(scope.row.id)">{{ t('update') }}</el-button>
          <el-button link size="small" @click="deleteHandle(scope.row.id)">{{ t('delete') }}</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="username" :label="t('customer.username')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="realName" :label="t('customer.realName')" header-align="center" width="120" align="center"></el-table-column>
      <el-table-column prop="headUrl" :label="t('customer.headUrl')" header-align="center" width="120" align="center"></el-table-column>
      <el-table-column prop="gender" :label="t('customer.gender')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="email" :label="t('customer.email')" header-align="center" width="240" align="center"></el-table-column>
      <el-table-column prop="mobile" :label="t('customer.mobile')" header-align="center" width="120" align="center"></el-table-column>
      <el-table-column prop="updateDate" :label="t('customer.updateDate')" header-align="center" width="180" align="center"></el-table-column>
      <el-table-column prop="createDate" :label="t('customer.createDate')" header-align="center" width="180" align="center"></el-table-column>
    </el-table>
    <el-pagination :current-page="hooksData.page"
                   :page-sizes="[10, 20, 50, 100]"
                   :page-size="hooksData.limit"
                   :total="hooksData.total"
                   layout="total, sizes, prev, pager, next, jumper"
                   :small="true"
                   @size-change="onPageSizeChange"
                   @current-change="onPageCurrentChange">
    </el-pagination>
    <edit-dialog v-if="hooksData.editDialogVisible"
                 ref="editDialogRef"
                 @refreshPageHandle="getDataList">
    </edit-dialog>
  </el-card>
</template>
<script setup lang="ts">
  import { watch } from 'vue'
  import useHooks from '@/hooks'
  import { useI18n } from 'vue-i18n'
  import EditDialog from './customer-edit-dialog.vue'

  const { t } = useI18n()

  const {
    hooksOptions,
    hooksData,
    getDataList,
    onPageSizeChange,
    onPageCurrentChange,
    deleteHandle,
    showEditDialogHandle
  } = useHooks()

  hooksOptions.getListURL = '/shop/customer/page'
  hooksOptions.needPage = true
  hooksOptions.deleteURL = '/shop/customer/delete'
  hooksOptions.multiDelete = false

  hooksData.dataForm = {
    productName: ''
  }

  watch([() => hooksData.daterange], (val1) => {
    hooksData.dataForm.startDate = val1[0][0]
    hooksData.dataForm.endDate = val1[0][1]
  })
</script>
