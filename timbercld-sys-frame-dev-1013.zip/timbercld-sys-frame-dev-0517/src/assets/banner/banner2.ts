export default function fn2() {
  console.log('                            (___  ___)       _                 / ___) |   |  _  \\____/\n')
  console.log('                               |  |_        | |               | |   | |   | |  \\ \\\n')
  console.log('                               |  (_).__.__ | |___  ____ __ __| |   | |   | |  | |\n')
  console.log('                               |  | | __ __\\|  _  \\/ __ \\  /_/| |   | |   | |  | |\n')
}
