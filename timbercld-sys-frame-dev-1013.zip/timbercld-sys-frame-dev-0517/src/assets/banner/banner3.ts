export default function fn3() {
  console.log('                               |  | | || || | (_) |  ___/| |  | |___| |___| |__/ /\n')
  console.log('                                \\_|_|_||_||_\\_____/\\____/|_|   \\____)\\____)_____/\n')
  console.log('                         ===++++++++======++++++++++++++==========+++++++============\n')
  console.log('                                     :: System Framework ::  (V1.0.0.RELEASE)\n')
}
