export default function fn4() {
  console.log('\n')
  console.log('               欢迎使用 timbercld-sys-frame 系统管理(启航版) - Powered By https://www.timbercld.com/\n')
  console.log('\n')
  console.log('====================================================================================================================\n')
}
