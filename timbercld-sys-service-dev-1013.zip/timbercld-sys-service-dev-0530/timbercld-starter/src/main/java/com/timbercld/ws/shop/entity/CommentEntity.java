package com.timbercld.ws.shop.entity;

public class CommentEntity {
}
