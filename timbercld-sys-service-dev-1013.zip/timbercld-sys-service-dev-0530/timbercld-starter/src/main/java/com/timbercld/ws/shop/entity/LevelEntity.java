package com.timbercld.ws.shop.entity;

public class LevelEntity {
}
